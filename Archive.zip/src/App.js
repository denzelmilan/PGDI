import React from 'react';
import './App.css';

function App() {
  return (
    <div className="container">
      <div className="card">
        <h1>Welcome to Your Auto-Help Tutor!</h1>
        <p>Ask your questions here:</p>
        {/* Input field and submit button */}
        <button className="my-button">Ask</button>
        {/* Display the tutor's response */}
      </div>
    </div>
  );
}

export default App;