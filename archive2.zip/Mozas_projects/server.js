const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Configura o body-parser para processar os dados do formulário
app.use(bodyParser.urlencoded({ extended: true }));

// Serve arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Rota principal ("/") que serve a página index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Rota para cadastrar os dados
app.post('/cadastrar', (req, res) => {
    const aluno = req.body;

    // Validação dos dados do aluno
    if (!aluno.nome || !aluno.idade || !aluno.curso || !aluno.disciplinas) {
        return res.status(400).json({ message: 'Por favor, preencha todos os campos.' });
    }

    // Formatação dos dados para salvar no arquivo
    const alunoData = `Nome: ${aluno.nome}\nIdade: ${aluno.idade}\nCurso: ${aluno.curso}\nDisciplinas: ${aluno.disciplinas.join(', ')}\n\n`;

    // Caminho completo do arquivo onde os dados serão salvos
    const filePath = path.join(__dirname, 'data.txt');

    // Verifica se o arquivo existe, caso contrário, cria o arquivo
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            // Se o arquivo não existe, cria um arquivo novo e escreve os dados
            fs.writeFile(filePath, alunoData, (writeErr) => {
                if (writeErr) {
                    console.error('Erro ao criar o arquivo:', writeErr);
                    return res.status(500).json({ message: 'Erro ao salvar os dados.' });
                }
                res.status(200).json({ message: 'Cadastro realizado com sucesso!' });
            });
        } else {
            // Se o arquivo existe, apenas adiciona os dados
            fs.appendFile(filePath, alunoData, (appendErr) => {
                if (appendErr) {
                    console.error('Erro ao adicionar os dados ao arquivo:', appendErr);
                    return res.status(500).json({ message: 'Erro ao salvar os dados.' });
                }
                res.status(200).json({ message: 'Cadastro realizado com sucesso!' });
            });
        }
    });
});

// Rota de interação com IA (simulada)
app.get('/interacao', (req, res) => {
    res.send(`
        <h1>Escolha uma disciplina para estudar</h1>
        <form action="/interacao" method="post">
            <select name="disciplinas">
                <option value="Comunicaçao Tecnica">Comunicaçao Tecnica</option>
                <option value="Processos de Gestao e Inovacao">Processos de Gestao  e Inovacao</option>
                <option value="Portugues">Portugues</option>
                <option value="Sistemas de Informaçao">Sistemas de Informaçao</option>
              
            </select>
            <button type="submit">Interagir com IA Ollama</button>
        </form>
    `);
});

// Inicializa o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
